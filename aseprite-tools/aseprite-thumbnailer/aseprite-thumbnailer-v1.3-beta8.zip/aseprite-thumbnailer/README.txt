Aseprite Thumbnails for Windows
===============================

1. Execute Install.bat to install the extension.
2. Don't delete or move the .dll files when the extension is installed.
3. Execute Uninstall.bat to uninstall it and then you can remove the files.

Contact us at support@aseprite.org for help
